var content=(function(){"use strict";const u=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function W(n){return n}function D(n){const e=(n??"").trim();if(!e||!e.startsWith("papercuts:"))return null;const t=e.slice(10),[r,s]=t.split("#"),o=(r??"").trim().replace(/\/+$/,""),i=(s??"").trim();return!o||!i?null:{baseUrl:o,apiKey:i}}function $(){const n=document.createElement("div");n.style.position="fixed",n.style.inset="0",n.style.zIndex="2147483647",n.style.cursor="crosshair",n.style.background="rgba(0,0,0,0.15)";const e=document.createElement("div");e.style.position="fixed",e.style.border="1px solid rgba(255,255,255,0.95)",e.style.background="rgba(0,0,0,0.25)",e.style.display="none",n.appendChild(e);const t=document.createElement("div");return t.textContent="Drag to select an area • Esc to cancel",t.style.position="fixed",t.style.left="12px",t.style.top="12px",t.style.padding="8px 10px",t.style.borderRadius="10px",t.style.border="1px solid rgba(255,255,255,0.35)",t.style.background="rgba(0,0,0,0.55)",t.style.color="white",t.style.font="14px system-ui, -apple-system, Segoe UI, Roboto, sans-serif",n.appendChild(t),{overlay:n,box:e,hint:t}}async function F(n){const e=new Image;e.src=n.dataUrl,await e.decode();const t=Math.max(0,Math.round(n.rect.x*n.dpr)),r=Math.max(0,Math.round(n.rect.y*n.dpr)),s=Math.max(1,Math.round(n.rect.width*n.dpr)),o=Math.max(1,Math.round(n.rect.height*n.dpr)),i=document.createElement("canvas");i.width=s,i.height=o;const m=i.getContext("2d");if(!m)throw new Error("No canvas");return m.drawImage(e,t,r,s,o,0,0,s,o),await(await new Promise((d,g)=>{i.toBlob(a=>a?d(a):g(new Error("toBlob")),"image/png")})).arrayBuffer()}async function M(){const{overlay:n,box:e}=$();document.documentElement.appendChild(n);let t=0,r=0,s=!1,o=!1,i=()=>{};const m=new Promise(a=>{i=a}),l=a=>{o||(o=!0,i(a))},d=()=>{n.remove(),window.removeEventListener("keydown",g,!0)},g=a=>{a.key==="Escape"&&(a.preventDefault(),d(),l(null))};return window.addEventListener("keydown",g,!0),n.addEventListener("mousedown",a=>{s=!0,t=a.clientX,r=a.clientY,e.style.display="block",e.style.left=`${t}px`,e.style.top=`${r}px`,e.style.width="0px",e.style.height="0px",a.preventDefault(),a.stopPropagation()},!0),n.addEventListener("mousemove",a=>{if(!s)return;const c=Math.min(t,a.clientX),h=Math.min(r,a.clientY),v=Math.max(t,a.clientX),E=Math.max(r,a.clientY);e.style.left=`${c}px`,e.style.top=`${h}px`,e.style.width=`${v-c}px`,e.style.height=`${E-h}px`,a.preventDefault(),a.stopPropagation()},!0),n.addEventListener("mouseup",async a=>{if(!s)return;s=!1;const c=Math.min(t,a.clientX),h=Math.min(r,a.clientY),v=Math.max(t,a.clientX),E=Math.max(r,a.clientY),C={x:c,y:h,width:v-c,height:E-h};if(d(),C.width<8||C.height<8)return l(null);try{const f=await u.runtime.sendMessage({type:"CAPTURE_VISIBLE"});if(!f||f.error||!f.dataUrl)return console.error("[Papercuts] Capture failed:",f?.error??"No dataUrl returned"),window.alert("Papercuts: Failed to capture screenshot. Please try again."),l(null);const R=await F({dataUrl:f.dataUrl,rect:C,dpr:window.devicePixelRatio||1});l(R)}catch(f){console.error("[Papercuts] Exception during capture:",f),window.alert("Papercuts: Screenshot capture failed. Please try again."),l(null)}},!0),await m}function U(n){const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.75);
    z-index: 2147483646;
    display: flex;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(2px);
  `;const t=document.createElement("div");t.style.cssText=`
    width: 80vw;
    height: 80vh;
    background: rgba(30, 30, 30, 0.98);
    border-radius: 16px;
    padding: 32px;
    display: flex;
    flex-direction: column;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.1);
  `;const r=document.createElement("div");r.style.cssText=`
    text-align: center;
    margin-bottom: 24px;
    color: white;
  `,r.innerHTML=`
    <h1 style="font-size: 24px; font-weight: 600; margin: 0 0 8px 0; font-family: system-ui, -apple-system, sans-serif;">Review & Annotate Screenshot</h1>
    <p style="color: rgba(255, 255, 255, 0.7); margin: 0; font-size: 14px; font-family: system-ui, -apple-system, sans-serif;">Draw on the screenshot to highlight important areas, then confirm or retake.</p>
  `;const s=document.createElement("div");s.style.cssText=`
    display: flex;
    align-items: center;
    gap: 24px;
    padding: 16px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
  `;const o=document.createElement("input");o.type="color",o.value="#ff0000",o.style.cssText=`
    width: 40px;
    height: 32px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
  `;const i=document.createElement("input");i.type="range",i.min="1",i.max="10",i.value="3",i.style.width="100px";const m=document.createElement("span");m.textContent="3px",m.style.cssText="color: white; font-size: 14px; font-family: system-ui, -apple-system, sans-serif;",i.addEventListener("input",()=>{m.textContent=`${i.value}px`});const l=document.createElement("button");l.textContent="Clear Annotations",l.style.cssText=`
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
    transition: background 0.2s;
  `,l.onmouseover=()=>l.style.background="rgba(255, 255, 255, 0.15)",l.onmouseout=()=>l.style.background="rgba(255, 255, 255, 0.1)";const d=document.createElement("label");d.style.cssText=`
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
  `,d.innerHTML="Color:",d.appendChild(o);const g=document.createElement("label");g.style.cssText=`
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
  `,g.innerHTML="Pen Size:",g.appendChild(i),g.appendChild(m),s.appendChild(d),s.appendChild(g),s.appendChild(l);const a=document.createElement("div");a.style.cssText=`
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 12px;
    padding: 20px;
    overflow: auto;
    margin-bottom: 24px;
  `;const c=document.createElement("canvas");c.style.cssText=`
    max-width: 100%;
    max-height: 100%;
    cursor: crosshair;
    border: 2px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    background: white;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
  `;const h=new Image;h.onload=()=>{c.width=h.width,c.height=h.height;const p=c.getContext("2d");p&&p.drawImage(h,0,0)},h.src=n.screenshotDataUrl,a.appendChild(c);let v=!1,E=0,C=0;const f=p=>{if(!c.getContext("2d"))return;v=!0;const w=c.getBoundingClientRect(),L=c.width/w.width,A=c.height/w.height;E=(p.clientX-w.left)*L,C=(p.clientY-w.top)*A},R=p=>{if(!v)return;const y=c.getContext("2d");if(!y)return;const w=c.getBoundingClientRect(),L=c.width/w.width,A=c.height/w.height,O=(p.clientX-w.left)*L,B=(p.clientY-w.top)*A;y.strokeStyle=o.value,y.lineWidth=Number(i.value),y.lineCap="round",y.lineJoin="round",y.beginPath(),y.moveTo(E,C),y.lineTo(O,B),y.stroke(),E=O,C=B},N=()=>{v=!1};c.addEventListener("mousedown",f),c.addEventListener("mousemove",R),c.addEventListener("mouseup",N),c.addEventListener("mouseleave",N),l.addEventListener("click",()=>{const p=c.getContext("2d");p&&(p.clearRect(0,0,c.width,c.height),p.drawImage(h,0,0))});const k=document.createElement("div");k.style.cssText=`
    display: flex;
    justify-content: center;
    gap: 16px;
  `;const x=document.createElement("button");x.textContent="Retake Screenshot",x.style.cssText=`
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
    transition: background 0.2s;
  `,x.onmouseover=()=>x.style.background="rgba(255, 255, 255, 0.15)",x.onmouseout=()=>x.style.background="rgba(255, 255, 255, 0.1)";const b=document.createElement("button");return b.textContent="Confirm & Continue",b.style.cssText=`
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    background: #0066cc;
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
    transition: background 0.2s;
  `,b.onmouseover=()=>b.style.background="#0052a3",b.onmouseout=()=>b.style.background="#0066cc",x.addEventListener("click",()=>{e.remove(),n.onRetake()}),b.addEventListener("click",()=>{const p=c.toDataURL("image/png");e.remove(),n.onConfirm(p)}),k.appendChild(x),k.appendChild(b),t.appendChild(r),t.appendChild(s),t.appendChild(a),t.appendChild(k),e.appendChild(t),e}const z={matches:["<all_urls>"],main(){u.runtime.onMessage.addListener(async n=>{const e=n;if(e?.type==="CAPTURE_AREA"){const t=await M();return t?{imageBytes:t}:{cancelled:!0}}if(e?.type==="START_SELECTION_OPEN_COMPOSER"){console.log("[Papercuts] Starting area selection flow...");const t=await M();if(!t)return console.log("[Papercuts] Area selection cancelled"),{cancelled:!0};console.log("[Papercuts] Area captured, resolving credentials...");let r=e.baseUrl,s=e.apiKey;if(!r||!s){const o=await u.storage.local.get(["papercuts_connect"]),i=D(typeof o.papercuts_connect=="string"?o.papercuts_connect:"");r=r??i?.baseUrl,s=s??i?.apiKey}if(!r)return console.error("[Papercuts] Missing Connect code"),window.alert("Papercuts: Missing Connect code. Open the extension popup and paste it first."),{error:"Missing connect code"};console.log("[Papercuts] Showing preview modal...");try{const o=new Blob([t],{type:"image/png"}),i=await new Promise(l=>{const d=new FileReader;d.onloadend=()=>l(d.result),d.readAsDataURL(o)}),m=U({screenshotDataUrl:i,onConfirm:async l=>{console.log("[Papercuts] Screenshot confirmed, opening Composer...");const d=await(await fetch(l)).blob(),g=new Uint8Array(await d.arrayBuffer());await u.storage.local.set({papercuts_connect:`papercuts:${r}#${s}`,pending_screenshot_bytes:Array.from(g)}),await u.runtime.sendMessage({type:"OPEN_COMPOSER_TAB"})},onRetake:async()=>{console.log("[Papercuts] Retaking screenshot..."),await u.runtime.sendMessage({type:"START_SELECTION_OPEN_COMPOSER",baseUrl:r,apiKey:s})}});return document.documentElement.appendChild(m),{ok:!0}}catch(o){return console.error("[Papercuts] Exception:",o),window.alert("Papercuts: Failed to show preview. Check console for details."),{error:String(o)}}}if(e?.type==="SHOW_PREVIEW_MODAL"){const t=U({screenshotDataUrl:e.screenshotDataUrl,onConfirm:async r=>{const s=await(await fetch(r)).blob(),o=new Uint8Array(await s.arrayBuffer());await u.storage.local.set({papercuts_connect:`papercuts:${e.baseUrl}#${e.apiKey}`,pending_screenshot_bytes:Array.from(o)}),await u.runtime.sendMessage({type:"OPEN_COMPOSER_TAB"})},onRetake:async()=>{await u.runtime.sendMessage({type:"START_SELECTION_OPEN_COMPOSER",baseUrl:e.baseUrl,apiKey:e.apiKey})}});return document.documentElement.appendChild(t),{ok:!0}}if(e?.type==="START_SELECTION"){const t=await M();if(!t)return;const r=await u.storage.local.get(["papercuts_connect"]),s=typeof r.papercuts_connect=="string"?r.papercuts_connect:"";let o=e.baseUrl??"http://localhost:3000",i;if(s.startsWith("papercuts:")){const m=s.slice(10),[l,d]=m.split("#");l?.trim()&&(o=l.trim()),d?.trim()&&(i=d.trim())}await u.runtime.sendMessage({type:"UPLOAD_AND_CREATE",baseUrl:o,apiKey:i,name:e.name??"New papercut",descriptionText:e.descriptionText??"",imageBytes:t})}})}};function T(n,...e){}const Y={debug:(...n)=>T(console.debug,...n),log:(...n)=>T(console.log,...n),warn:(...n)=>T(console.warn,...n),error:(...n)=>T(console.error,...n)};class I extends Event{constructor(e,t){super(I.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=t}static EVENT_NAME=_("wxt:locationchange")}function _(n){return`${u?.runtime?.id}:content:${n}`}function X(n){let e,t;return{run(){e==null&&(t=new URL(location.href),e=n.setInterval(()=>{let r=new URL(location.href);r.href!==t.href&&(window.dispatchEvent(new I(r,t)),t=r)},1e3))}}}class S{constructor(e,t){this.contentScriptName=e,this.options=t,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=_("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=X(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return u.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,t){const r=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(e,t){const r=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(e){const t=requestAnimationFrame((...r)=>{this.isValid&&e(...r)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){const r=requestIdleCallback((...s)=>{this.signal.aborted||e(...s)},t);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(e,t,r,s){t==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith("wxt:")?_(t):t,r,{...s,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),Y.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:S.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){const t=e.data?.type===S.SCRIPT_STARTED_MESSAGE_TYPE,r=e.data?.contentScriptName===this.contentScriptName,s=!this.receivedMessageIds.has(e.data?.messageId);return t&&r&&s}listenForNewerScripts(e){let t=!0;const r=s=>{if(this.verifyScriptStartedEvent(s)){this.receivedMessageIds.add(s.data.messageId);const o=t;if(t=!1,o&&e?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}}function q(){}function P(n,...e){}const K={debug:(...n)=>P(console.debug,...n),log:(...n)=>P(console.log,...n),warn:(...n)=>P(console.warn,...n),error:(...n)=>P(console.error,...n)};return(async()=>{try{const{main:n,...e}=z,t=new S("content",e);return await n(t)}catch(n){throw K.error('The content script "content" crashed on startup!',n),n}})()})();
content;