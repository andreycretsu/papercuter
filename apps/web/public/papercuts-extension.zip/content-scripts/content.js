var content=(function(){"use strict";const p=globalThis.browser?.runtime?.id?globalThis.browser:globalThis.chrome;function q(n){return n}function $(n){const e=(n??"").trim();if(!e||!e.startsWith("papercuts:"))return null;const t=e.slice(10),[r,o]=t.split("#"),a=(r??"").trim().replace(/\/+$/,""),i=(o??"").trim();return!a||!i?null:{baseUrl:a,apiKey:i}}function F(){const n=document.createElement("div");n.style.position="fixed",n.style.inset="0",n.style.zIndex="2147483647",n.style.cursor="crosshair",n.style.background="rgba(0,0,0,0.15)";const e=document.createElement("div");e.style.position="fixed",e.style.border="1px solid rgba(255,255,255,0.95)",e.style.background="rgba(0,0,0,0.25)",e.style.display="none",n.appendChild(e);const t=document.createElement("div");return t.textContent="Drag to select an area • Esc to cancel",t.style.position="fixed",t.style.left="12px",t.style.top="12px",t.style.padding="8px 10px",t.style.borderRadius="10px",t.style.border="1px solid rgba(255,255,255,0.35)",t.style.background="rgba(0,0,0,0.55)",t.style.color="white",t.style.font="14px system-ui, -apple-system, Segoe UI, Roboto, sans-serif",n.appendChild(t),{overlay:n,box:e,hint:t}}async function z(n){const e=new Image;e.src=n.dataUrl,await e.decode();const t=Math.max(0,Math.round(n.rect.x*n.dpr)),r=Math.max(0,Math.round(n.rect.y*n.dpr)),o=Math.max(1,Math.round(n.rect.width*n.dpr)),a=Math.max(1,Math.round(n.rect.height*n.dpr)),i=document.createElement("canvas");i.width=o,i.height=a;const u=i.getContext("2d");if(!u)throw new Error("No canvas");return u.drawImage(e,t,r,o,a,0,0,o,a),await(await new Promise((l,m)=>{i.toBlob(x=>x?l(x):m(new Error("toBlob")),"image/png")})).arrayBuffer()}let _=!1;async function R(){if(_)return console.log("[Papercuts] Capture already in progress, ignoring..."),null;_=!0;const{overlay:n,box:e}=F();document.documentElement.appendChild(n);let t=0,r=0,o=!1,a=!1,i=()=>{};const u=new Promise(s=>{i=s}),c=s=>{a||(a=!0,i(s))},l=()=>{n.remove(),window.removeEventListener("keydown",m,!0)},m=s=>{s.key==="Escape"&&(s.preventDefault(),l(),c(null))};window.addEventListener("keydown",m,!0),n.addEventListener("mousedown",s=>{o=!0,t=s.clientX,r=s.clientY,e.style.display="block",e.style.left=`${t}px`,e.style.top=`${r}px`,e.style.width="0px",e.style.height="0px",s.preventDefault(),s.stopPropagation()},!0),n.addEventListener("mousemove",s=>{if(!o)return;const g=Math.min(t,s.clientX),y=Math.min(r,s.clientY),E=Math.max(t,s.clientX),C=Math.max(r,s.clientY);e.style.left=`${g}px`,e.style.top=`${y}px`,e.style.width=`${E-g}px`,e.style.height=`${C-y}px`,s.preventDefault(),s.stopPropagation()},!0),n.addEventListener("mouseup",async s=>{if(!o)return;o=!1;const g=Math.min(t,s.clientX),y=Math.min(r,s.clientY),E=Math.max(t,s.clientX),C=Math.max(r,s.clientY),T={x:g,y,width:E-g,height:C-y};if(l(),T.width<8||T.height<8)return c(null);try{const f=await p.runtime.sendMessage({type:"CAPTURE_VISIBLE"});if(!f||f.error||!f.dataUrl)return console.error("[Papercuts] Capture failed:",f?.error??"No dataUrl returned"),window.alert("Papercuts: Failed to capture screenshot. Please try again."),c(null);const M=await z({dataUrl:f.dataUrl,rect:T,dpr:window.devicePixelRatio||1});c(M)}catch(f){console.error("[Papercuts] Exception during capture:",f),window.alert("Papercuts: Screenshot capture failed. Please try again."),c(null)}},!0);const x=await u;return _=!1,x}function O(n){const e=document.createElement("div");e.style.cssText=`
    position: fixed;
    inset: 0;
    background: rgba(0, 0, 0, 0.75);
    z-index: 2147483646;
    display: flex;
    align-items: center;
    justify-content: center;
    backdrop-filter: blur(2px);
  `;const t=document.createElement("div");t.style.cssText=`
    width: 80vw;
    height: 80vh;
    background: rgba(30, 30, 30, 0.98);
    border-radius: 16px;
    padding: 32px;
    display: flex;
    flex-direction: column;
    box-shadow: 0 20px 60px rgba(0, 0, 0, 0.5);
    border: 1px solid rgba(255, 255, 255, 0.1);
  `;const r=document.createElement("div");r.style.cssText=`
    text-align: center;
    margin-bottom: 24px;
    color: white;
  `,r.innerHTML=`
    <h1 style="font-size: 24px; font-weight: 600; margin: 0 0 8px 0; font-family: system-ui, -apple-system, sans-serif;">Review & Annotate Screenshot</h1>
    <p style="color: rgba(255, 255, 255, 0.7); margin: 0; font-size: 14px; font-family: system-ui, -apple-system, sans-serif;">Draw on the screenshot to highlight important areas, then confirm or retake.</p>
  `;const o=document.createElement("div");o.style.cssText=`
    display: flex;
    align-items: center;
    gap: 24px;
    padding: 16px;
    background: rgba(255, 255, 255, 0.08);
    border-radius: 10px;
    margin-bottom: 20px;
    flex-wrap: wrap;
  `;const a=document.createElement("input");a.type="color",a.value="#ff0000",a.style.cssText=`
    width: 40px;
    height: 32px;
    border: none;
    border-radius: 6px;
    cursor: pointer;
  `;const i=document.createElement("input");i.type="range",i.min="1",i.max="10",i.value="3",i.style.width="100px";const u=document.createElement("span");u.textContent="3px",u.style.cssText="color: white; font-size: 14px; font-family: system-ui, -apple-system, sans-serif;",i.addEventListener("input",()=>{u.textContent=`${i.value}px`});const c=document.createElement("button");c.textContent="Clear Annotations",c.style.cssText=`
    padding: 8px 16px;
    border: none;
    border-radius: 8px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
    transition: background 0.2s;
  `,c.onmouseover=()=>c.style.background="rgba(255, 255, 255, 0.15)",c.onmouseout=()=>c.style.background="rgba(255, 255, 255, 0.1)";const l=document.createElement("label");l.style.cssText=`
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
  `,l.innerHTML="Color:",l.appendChild(a);const m=document.createElement("label");m.style.cssText=`
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 14px;
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
  `,m.innerHTML="Pen Size:",m.appendChild(i),m.appendChild(u),o.appendChild(l),o.appendChild(m),o.appendChild(c);const x=document.createElement("div");x.style.cssText=`
    flex: 1;
    display: flex;
    justify-content: center;
    align-items: center;
    background: rgba(0, 0, 0, 0.3);
    border-radius: 12px;
    padding: 20px;
    overflow: auto;
    margin-bottom: 24px;
  `;const s=document.createElement("canvas");s.style.cssText=`
    max-width: 100%;
    max-height: 100%;
    cursor: crosshair;
    border: 2px solid rgba(255, 255, 255, 0.2);
    border-radius: 8px;
    background: white;
    box-shadow: 0 4px 16px rgba(0, 0, 0, 0.3);
  `;const g=new Image;g.onload=()=>{s.width=g.width,s.height=g.height;const d=s.getContext("2d");d&&d.drawImage(g,0,0)},g.src=n.screenshotDataUrl,x.appendChild(s);let y=!1,E=0,C=0;const T=d=>{if(!s.getContext("2d"))return;y=!0;const w=s.getBoundingClientRect(),U=s.width/w.width,N=s.height/w.height;E=(d.clientX-w.left)*U,C=(d.clientY-w.top)*N},f=d=>{if(!y)return;const h=s.getContext("2d");if(!h)return;const w=s.getBoundingClientRect(),U=s.width/w.width,N=s.height/w.height,B=(d.clientX-w.left)*U,D=(d.clientY-w.top)*N;h.strokeStyle=a.value,h.lineWidth=Number(i.value),h.lineCap="round",h.lineJoin="round",h.beginPath(),h.moveTo(E,C),h.lineTo(B,D),h.stroke(),E=B,C=D},M=()=>{y=!1};s.addEventListener("mousedown",T),s.addEventListener("mousemove",f),s.addEventListener("mouseup",M),s.addEventListener("mouseleave",M),c.addEventListener("click",()=>{const d=s.getContext("2d");d&&(d.clearRect(0,0,s.width,s.height),d.drawImage(g,0,0))});const I=document.createElement("div");I.style.cssText=`
    display: flex;
    justify-content: center;
    gap: 16px;
  `;const b=document.createElement("button");b.textContent="Retake Screenshot",b.style.cssText=`
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    background: rgba(255, 255, 255, 0.1);
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
    transition: background 0.2s;
  `,b.onmouseover=()=>b.style.background="rgba(255, 255, 255, 0.15)",b.onmouseout=()=>b.style.background="rgba(255, 255, 255, 0.1)";const v=document.createElement("button");return v.textContent="Confirm & Continue",v.style.cssText=`
    padding: 12px 24px;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 500;
    cursor: pointer;
    background: #0066cc;
    color: white;
    font-family: system-ui, -apple-system, sans-serif;
    transition: background 0.2s;
  `,v.onmouseover=()=>v.style.background="#0052a3",v.onmouseout=()=>v.style.background="#0066cc",b.addEventListener("click",()=>{e.remove(),n.onRetake()}),v.addEventListener("click",()=>{const d=s.toDataURL("image/png");e.remove(),n.onConfirm(d)}),I.appendChild(b),I.appendChild(v),t.appendChild(r),t.appendChild(o),t.appendChild(x),t.appendChild(I),e.appendChild(t),e}const Y={matches:["<all_urls>"],main(){p.runtime.onMessage.addListener(async n=>{const e=n;if(e?.type==="CAPTURE_AREA"){const t=await R();return t?{imageBytes:t}:{cancelled:!0}}if(e?.type==="START_SELECTION_OPEN_COMPOSER"){console.log("[Papercuts] Starting area selection flow...");const t=await R();if(!t)return console.log("[Papercuts] Area selection cancelled"),{cancelled:!0};console.log("[Papercuts] Area captured, resolving credentials...");let r=e.baseUrl,o=e.apiKey;if(!r||!o){const a=await p.storage.local.get(["papercuts_connect"]),i=$(typeof a.papercuts_connect=="string"?a.papercuts_connect:"");r=r??i?.baseUrl,o=o??i?.apiKey}if(!r)return console.error("[Papercuts] Missing Connect code"),window.alert("Papercuts: Missing Connect code. Open the extension popup and paste it first."),{error:"Missing connect code"};console.log("[Papercuts] Showing preview modal...");try{const a=new Blob([t],{type:"image/png"}),i=await new Promise(c=>{const l=new FileReader;l.onloadend=()=>c(l.result),l.readAsDataURL(a)}),u=O({screenshotDataUrl:i,onConfirm:async c=>{console.log("[Papercuts] Screenshot confirmed, opening Composer...");const l=await(await fetch(c)).blob(),m=new Uint8Array(await l.arrayBuffer());await p.storage.local.set({papercuts_connect:`papercuts:${r}#${o}`,pending_screenshot_bytes:Array.from(m)}),await p.runtime.sendMessage({type:"OPEN_COMPOSER_TAB"})},onRetake:async()=>{console.log("[Papercuts] Retaking screenshot..."),await p.runtime.sendMessage({type:"START_SELECTION_OPEN_COMPOSER",baseUrl:r,apiKey:o})}});return document.documentElement.appendChild(u),{ok:!0}}catch(a){return console.error("[Papercuts] Exception:",a),window.alert("Papercuts: Failed to show preview. Check console for details."),{error:String(a)}}}if(e?.type==="SHOW_PREVIEW_MODAL"){const t=O({screenshotDataUrl:e.screenshotDataUrl,onConfirm:async r=>{const o=await(await fetch(r)).blob(),a=new Uint8Array(await o.arrayBuffer());await p.storage.local.set({papercuts_connect:`papercuts:${e.baseUrl}#${e.apiKey}`,pending_screenshot_bytes:Array.from(a)}),await p.runtime.sendMessage({type:"OPEN_COMPOSER_TAB"})},onRetake:async()=>{await p.runtime.sendMessage({type:"START_SELECTION_OPEN_COMPOSER",baseUrl:e.baseUrl,apiKey:e.apiKey})}});return document.documentElement.appendChild(t),{ok:!0}}if(e?.type==="START_SELECTION"){const t=await R();if(!t)return;const r=await p.storage.local.get(["papercuts_connect"]),o=typeof r.papercuts_connect=="string"?r.papercuts_connect:"";let a=e.baseUrl??"http://localhost:3000",i;if(o.startsWith("papercuts:")){const u=o.slice(10),[c,l]=u.split("#");c?.trim()&&(a=c.trim()),l?.trim()&&(i=l.trim())}await p.runtime.sendMessage({type:"UPLOAD_AND_CREATE",baseUrl:a,apiKey:i,name:e.name??"New papercut",descriptionText:e.descriptionText??"",imageBytes:t})}})}};function S(n,...e){}const X={debug:(...n)=>S(console.debug,...n),log:(...n)=>S(console.log,...n),warn:(...n)=>S(console.warn,...n),error:(...n)=>S(console.error,...n)};class L extends Event{constructor(e,t){super(L.EVENT_NAME,{}),this.newUrl=e,this.oldUrl=t}static EVENT_NAME=A("wxt:locationchange")}function A(n){return`${p?.runtime?.id}:content:${n}`}function K(n){let e,t;return{run(){e==null&&(t=new URL(location.href),e=n.setInterval(()=>{let r=new URL(location.href);r.href!==t.href&&(window.dispatchEvent(new L(r,t)),t=r)},1e3))}}}class P{constructor(e,t){this.contentScriptName=e,this.options=t,this.abortController=new AbortController,this.isTopFrame?(this.listenForNewerScripts({ignoreFirstEvent:!0}),this.stopOldScripts()):this.listenForNewerScripts()}static SCRIPT_STARTED_MESSAGE_TYPE=A("wxt:content-script-started");isTopFrame=window.self===window.top;abortController;locationWatcher=K(this);receivedMessageIds=new Set;get signal(){return this.abortController.signal}abort(e){return this.abortController.abort(e)}get isInvalid(){return p.runtime.id==null&&this.notifyInvalidated(),this.signal.aborted}get isValid(){return!this.isInvalid}onInvalidated(e){return this.signal.addEventListener("abort",e),()=>this.signal.removeEventListener("abort",e)}block(){return new Promise(()=>{})}setInterval(e,t){const r=setInterval(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearInterval(r)),r}setTimeout(e,t){const r=setTimeout(()=>{this.isValid&&e()},t);return this.onInvalidated(()=>clearTimeout(r)),r}requestAnimationFrame(e){const t=requestAnimationFrame((...r)=>{this.isValid&&e(...r)});return this.onInvalidated(()=>cancelAnimationFrame(t)),t}requestIdleCallback(e,t){const r=requestIdleCallback((...o)=>{this.signal.aborted||e(...o)},t);return this.onInvalidated(()=>cancelIdleCallback(r)),r}addEventListener(e,t,r,o){t==="wxt:locationchange"&&this.isValid&&this.locationWatcher.run(),e.addEventListener?.(t.startsWith("wxt:")?A(t):t,r,{...o,signal:this.signal})}notifyInvalidated(){this.abort("Content script context invalidated"),X.debug(`Content script "${this.contentScriptName}" context invalidated`)}stopOldScripts(){window.postMessage({type:P.SCRIPT_STARTED_MESSAGE_TYPE,contentScriptName:this.contentScriptName,messageId:Math.random().toString(36).slice(2)},"*")}verifyScriptStartedEvent(e){const t=e.data?.type===P.SCRIPT_STARTED_MESSAGE_TYPE,r=e.data?.contentScriptName===this.contentScriptName,o=!this.receivedMessageIds.has(e.data?.messageId);return t&&r&&o}listenForNewerScripts(e){let t=!0;const r=o=>{if(this.verifyScriptStartedEvent(o)){this.receivedMessageIds.add(o.data.messageId);const a=t;if(t=!1,a&&e?.ignoreFirstEvent)return;this.notifyInvalidated()}};addEventListener("message",r),this.onInvalidated(()=>removeEventListener("message",r))}}function H(){}function k(n,...e){}const V={debug:(...n)=>k(console.debug,...n),log:(...n)=>k(console.log,...n),warn:(...n)=>k(console.warn,...n),error:(...n)=>k(console.error,...n)};return(async()=>{try{const{main:n,...e}=Y,t=new P("content",e);return await n(t)}catch(n){throw V.error('The content script "content" crashed on startup!',n),n}})()})();
content;